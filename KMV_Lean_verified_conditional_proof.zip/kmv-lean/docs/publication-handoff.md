# Publication and Palomar handoff

The mathematical proof is complete for the authorized conditional target.
The source and verification reports are reviewable locally. Nothing has been
published or submitted.

Confirmed publication metadata:

- Human formalization author: Abhishek Methuku.
- Responsible maintainer: Abhishek Methuku.
- Software license: Apache-2.0, applied in the root `LICENSE`.
- Submitter relationship: responsible author or maintainer.

The user explicitly confirmed these choices. Codex's role in generating the
Lean development is recorded under automation. No human proof review is claimed.
The manuscript and dependencies retain their existing rights.

The remaining input is the public GitHub owner/repository with write access
and authorization to publish the snapshot there. Once available, push the final
commit and run `.github/workflows/palomar-preflight.yml` at that full 40-character SHA.
The workflow and pipeline input are pinned to the same official revision,
`c02bbeaed888df45c4e28c4e99dba540ad21552a`, with mode `full` and the standard
execution profile. Inspect every report and fix failures before submission.

The prepared submission layout is:

- Repository: not assigned.
- Commit: see `evidence/commit-binding.json` for the current local snapshot,
  including the approved metadata and license.
- Project path: repository root.
- Comparator path: `comparator.json`.
- Metadata path: `formalization.yaml`.
- Compared theorem: `KMV.main_result`.
- Authorization relationship: `I am a responsible author or maintainer`.

The original task reserves browser authentication and final submission to the
user. The agent must not drive Palomar browser sign-in. An agent/API route would
need separate explicit agreement on the exact repository, commit, paths and
relationship, under Palomar's current protocol. A successful local proof check
or full preflight is not registration. Register only after the review is available
and the user has authorized that permanent action. Preserve private submission
URLs and tokens outside public artifacts.
