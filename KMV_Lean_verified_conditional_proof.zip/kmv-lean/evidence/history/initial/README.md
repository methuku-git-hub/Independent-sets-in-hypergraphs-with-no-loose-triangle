# Independent sets in hypergraphs with no loose triangle

Initial formalisation checkpoint; **not certified and not ready for submission**.

The source is manuscript version 20, Theorem 1.3. The exact source and its
SHA-256 are recorded in manuscript/provenance.json. It is a working manuscript,
not a claimed published or arXiv version.

Challenge.lean states the full mixed-rank target, with its one permitted
statement placeholder. KMV/Basic.lean begins the definitions and elementary
proofs; these have **not been checked by Lean**. There is no Solution module.
No claim of a completed proof, axiom audit, or dependency closure is made.

The supported starter toolchain and exact Mathlib manifest were recovered.
The official Lean archive passed its advertised SHA-256 check. Lake runs, but
Lean itself exits with `error: failed to locate application` in this execution
environment. The environment denies reading /proc/<pid>/exe; /proc/self/exe
is readable. No compiler modification or permission workaround was attempted.

Once Lean works in a supported environment: `lake exe cache get; lake build`.
This is an intended build command, not evidence of a successful build.

A conditional formalisation from the precise Li–Postle theorem is permitted
by Palomar, but is a different certification scope from full dependency
closure. The user asked about that possibility; no conditional proof has
been completed or registered. The original unconditional target remains.

No software licence or repository identity has been authorised. Nothing has
been published or submitted. The manuscript retains its existing rights.
