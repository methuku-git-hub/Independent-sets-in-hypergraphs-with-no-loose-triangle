# Research and verification ledger — 2026-10-25

## Exact objective
For each integer r ≥ 3 there exist c > 0 and N such that every n ≥ N and
every loose-triangle-free hypergraph on n vertices with edge sizes in [3,r]
has an independent set of size at least c n^(2/3) (log log n)^(1/3).

## Statement correspondence
The ambient type Fin n fixes the number of vertices, including isolated
vertices. A Finset of Finsets prohibits repeated edges. RankBounds imposes
both edge-size bounds; LooseTriangle includes all three singleton pairwise
intersections and the empty triple intersection. Independent forbids any
edge contained in I. The existential set formulation is equivalent to the
independence-number bound because a finite hypergraph has a maximum independent
set. This equivalence and relabelling from an arbitrary n-element type are
mathematical observations here, not checked Lean theorems. Real exponents are
explicitly typed as real numbers. c and N precede n and H in the quantifiers.

## Status
No manuscript lemma has yet been formally verified. Two elementary proof
terms and the principal statement are drafted but unchecked. No mathematical
repair has been made. No counterexample has been found by the source reading;
that reading does not establish correctness. No claim of absence of gaps.

The complete Li–Postle dependency closure has not been mapped or formalised.
The inspected pinned Mathlib source search and public search did not identify
an existing Li–Postle formalisation; this is not an exhaustive absence claim.

## Precise next work
1. Run the official pinned Lean binary in an environment where it can locate
   its executable, then check Challenge and Basic; repair elaboration errors.
2. Formalise expandable-set extension (Lemma 4.1), keeping cardinality ≤ 2r
   and the three choices explicit.
3. Formalise compression and the sampling process, plus the classification.
4. Keep Li–Postle unresolved unless its formal proof is supplied or the user
   selects an explicitly conditional certification target.
5. Derive actual declaration closure and audit axioms only from compiled proofs.

## External status
No public repository, authorised licence, confirmed responsible formalisation
maintainer, official preflight run, editorial review, or registration exists.

## Conditional route
The official how-to-submit page expressly allows explicit hypotheses, while
forbidding custom axioms. Thus a fully checked implication from the precise
Li–Postle statement can be a submission target. It verifies our deduction,
not the external theorem. No conditional result has yet been proved here.
